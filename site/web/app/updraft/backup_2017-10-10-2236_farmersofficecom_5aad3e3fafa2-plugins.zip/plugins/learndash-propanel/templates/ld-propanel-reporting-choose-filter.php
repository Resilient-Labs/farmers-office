<?php
/**
 * Learndash ProPanel Choose Filter
 */
?>

<div class="propanel-reporting">
	<strong class="note please-choose-filter"><?php esc_html_e( 'Please choose a filter in ProPanel Reporting.', 'ld_propanel' ); ?></strong>
</div>
