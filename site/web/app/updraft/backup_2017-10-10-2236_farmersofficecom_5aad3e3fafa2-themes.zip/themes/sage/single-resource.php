<?php get_template_part('templates/content-single-resource', get_post_type()); ?>
<?php get_template_part('templates/components/help-banner'); ?>
