<section>
    <h1>Let's Get Started</h1>
    <a href="">
        <button>Enroll Now</button>
    </a>
</section>