<?php get_template_part('templates/content-single-resource'); ?>
<?php get_template_part('templates/components/help-banner'); ?>
