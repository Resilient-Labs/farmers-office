<section class="footer-footnote">
    <?php wp_nav_menu(); ?>
    <small>
    Farmer’s Office © <?php echo date("Y"); ?> | All Rights Reserved | Site designed and developed by 
        <a href="www.resilientcoders.org" target="_blank">Resilient Coders</a>  
    | Photography courtesy of ShutterStock
    </small>
</section>