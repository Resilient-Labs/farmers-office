<?php
defined( 'ABSPATH' ) or die( 'Cheatin&#8217; uh?' );

$this->load_plugin_settings( 'wp-endpoints' );
$this->load_plugin_settings( 'content-protect' );
$this->load_plugin_settings( 'page-protect' );
