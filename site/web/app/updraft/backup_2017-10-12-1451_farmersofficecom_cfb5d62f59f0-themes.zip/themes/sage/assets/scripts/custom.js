(function() {
    console.log("custom loaded");
})();