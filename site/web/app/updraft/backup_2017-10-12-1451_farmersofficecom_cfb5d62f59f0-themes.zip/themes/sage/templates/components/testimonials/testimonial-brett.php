<section class="testimonial">
    <blockquote>
    “Julia helped me stop guessing about what really makes money  vs. what I grow for no good reason. Julia will help you streamline your necessary accounting and bookkeeping chores so that you can get back to farming.”
    </blockquote>
    <img src="" >
    <span class="reference">Brett Grohsgal</span>
    <span class="company">Even’ Star Organic Farm</span>
</section>