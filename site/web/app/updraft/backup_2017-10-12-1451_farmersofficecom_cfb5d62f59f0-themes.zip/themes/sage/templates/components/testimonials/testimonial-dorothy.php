<section class="testimonial">
    <blockquote>
    “Julia is an intensely knowledgeable speaker able to adapt her teaching to the needs of her audience. Her talks are filled with stories and practical knowledge that are easily applied to real world business challenges”
    </blockquote>
    <img src="" >
    <span class="reference">Dorothy Suput</span>
    <span class="company">Executive Director, The Carrot Project</span>
</section>